import React, { useState } from "react";

import { makeStyles } from "@material-ui/core/styles";
import Paper from "@material-ui/core/Paper";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";
import TextField from "@material-ui/core/TextField";
import Button from "@material-ui/core/Button";
import { toast } from "react-toastify";

import api from "../../services/api";
import { i18n } from "../../translate/i18n.js";
import toastError from "../../errors/toastError";

const useStyles = makeStyles(theme => ({
  root: {
    display: "flex",
    alignItems: "center",
    padding: theme.spacing(8, 8, 3),
  },

  paper: {
    padding: theme.spacing(2),
    display: "flex",
    alignItems: "center",
    marginBottom: 12,
  },

  settingOption: {
    marginLeft: "auto",
  },
  margin: {
    margin: theme.spacing(1),
  },
}));

const SingleGroupDemote = () => {
  const classes = useStyles();
  const [participants, setParticipants] = useState([]);
  const [whatsappId, setWhatsappId] = useState("");
  const [groupId, setGroupId] = useState("");

  const handleChangeSetting = async () => {
    const participantsArray = participants.split(',').map(participant => participant.trim());
    const data = {
      participants: participantsArray,
      whatsappId: parseInt(whatsappId),
      groupId: groupId,
    };

    try {
      await api.post(`/zdgSingleDemote/`, data);
      toast.success(i18n.t("settings.success"));
    } catch (err) {
      toastError(err);
    }
  };

  return (
    <div className={classes.root}>
      <Container className={classes.container} maxWidth="sm">
        <Typography variant="body2" gutterBottom>
          {i18n.t("mainDrawer.listItems.singleGroupDemote")}
        </Typography>
        <Paper className={classes.paper}>
          <TextField
            label={i18n.t("commonLabels.participantsList")}
            margin="dense"
            variant="outlined"
            fullWidth
            value={participants}
            onChange={(e) => setParticipants(e.target.value)}
          />
        </Paper>
        <Paper className={classes.paper}>
          <TextField
            label={i18n.t("commonLabels.whatsAppID")}
            margin="dense"
            variant="outlined"
            fullWidth
            value={whatsappId}
            onChange={(e) => setWhatsappId(e.target.value)}
          />
        </Paper>
        <Paper className={classes.paper}>
          <TextField
            label={i18n.t("commonLabels.groupId")}
            margin="dense"
            variant="outlined"
            fullWidth
            value={groupId}
            onChange={(e) => setGroupId(e.target.value)}
          />
        </Paper>
        <Button
          variant="contained"
          color="primary"
          onClick={handleChangeSetting}
        >
          {i18n.t("commonLabels.action")}
        </Button>
      </Container>
    </div>
  );
};

export default SingleGroupDemote;
