import React, { useState, useEffect, useReducer } from "react";
import openSocket from "../../services/socket-io";

import {
  Button,
  IconButton,
  makeStyles,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  InputAdornment,
  TextField,
} from "@material-ui/core";
import { Edit, DeleteOutline } from "@material-ui/icons";
import SearchIcon from "@material-ui/icons/Search";

import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";
import Title from "../../components/Title";

import api from "../../services/api";
import { i18n } from "../../translate/i18n";
import TableRowSkeleton from "../../components/TableRowSkeleton";
import FarewellMessageModal from "../../components/FarewellMessageModal";
import ConfirmationModal from "../../components/ConfirmationModal";
import { toast } from "react-toastify";
import toastError from "../../errors/toastError";

const reducer = (state, action) => {
  if (action.type === "LOAD_FAREWELL_MESSAGE") {
    const farewellMessage = action.payload;
    const newFarewellMessage = [];

    farewellMessage.forEach((message) => {
      const farewellMessageIndex = state.findIndex((m) => m.id === message.id);
      if (farewellMessageIndex !== -1) {
        state[farewellMessageIndex] = message;
      } else {
        newFarewellMessage.push(message);
      }
    });

    return [...state, ...newFarewellMessage];
  }

  if (action.type === "UPDATE_FAREWELL_MESSAGE") {
    const farewellMessage = action.payload;
    const farewellMessageIndex = state.findIndex((m) => m.id === farewellMessage.id);

    if (farewellMessageIndex !== -1) {
      state[farewellMessageIndex] = farewellMessage;
      return [...state];
    } else {
      return [farewellMessage, ...state];
    }
  }

  if (action.type === "DELETE_FAREWELL_MESSAGE") {
    const farewellMessageId = action.payload;

    const farewellMessageIndex = state.findIndex((m) => m.id === farewellMessageId);
    if (farewellMessageIndex !== -1) {
      state.splice(farewellMessageIndex, 1);
    }
    return [...state];
  }

  if (action.type === "RESET") {
    return [];
  }
};

const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(1),
    overflowY: "scroll",
    ...theme.scrollbarStyles,
  },
}));

const FarewellMessage = () => {
  const classes = useStyles();

  const [loading, setLoading] = useState(false);
  const [pageNumber, setPageNumber] = useState(1);
  const [searchParam, setSearchParam] = useState("");
  const [farewellMessage, dispatch] = useReducer(reducer, []);
  const [selectedFarewellMessage, setSelectedFarewellMessage] = useState(null);
  const [farewellMessageModalOpen, setFarewellMessageModalOpen] = useState(false);
  const [deletingFarewellMessage, setDeletingFarewellMessage] = useState(null);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  const [hasMore, setHasMore] = useState(false);

  useEffect(() => {
    dispatch({ type: "RESET" });
    setPageNumber(1);
  }, [searchParam]);

  useEffect(() => {
    setLoading(true);
    const delayDebounceFn = setTimeout(() => {
      const fetchFarewellMessage = async () => {
        try {
          const { data } = await api.get("/farewellMessage/", {
            params: { searchParam, pageNumber },
          });
          dispatch({ type: "LOAD_FAREWELL_MESSAGE", payload: data.farewellMessage });
          setHasMore(data.hasMore);
          setLoading(false);
        } catch (err) {
          toastError(err);
        }
      };
      fetchFarewellMessage();
    }, 500);
    return () => clearTimeout(delayDebounceFn);
  }, [searchParam, pageNumber]);

  useEffect(() => {
    const socket = openSocket();

    socket.on("farewellMessage", (data) => {
      if (data.action === "update" || data.action === "create") {
        dispatch({ type: "UPDATE_FAREWELL_MESSAGE", payload: data.farewellMessage });
      }

      if (data.action === "delete") {
        dispatch({
          type: "DELETE_FAREWELL_MESSAGE",
          payload: +data.farewellMessageId,
        });
      }
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const handleSearch = (event) => {
    setSearchParam(event.target.value.toLowerCase());
  };

  const handleOpenFarewellMessageModal = () => {
    setSelectedFarewellMessage(null);
    setFarewellMessageModalOpen(true);
  };

  const handleCloseFarewellMessageModal = () => {
    setSelectedFarewellMessage(null);
    setFarewellMessageModalOpen(false);
  };

  const handleEditFarewellMessage = (farewellMessage) => {
    setSelectedFarewellMessage(farewellMessage);
    setFarewellMessageModalOpen(true);
  };

  const handleDeleteFarewellMessage = async (farewellMessageId) => {
    try {
      await api.delete(`/farewellMessage/${farewellMessageId}`);
      toast.success(i18n.t("farewell.toasts.deleted"));
    } catch (err) {
      toastError(err);
    }
    setDeletingFarewellMessage(null);
    setSearchParam("");
    setPageNumber(1);
  };

  const confirmDeleteAllFarewellMessage = () => {
    const confirm = window.confirm(i18n.t("farewell.popup.confirm"));
    if (confirm) {
      handleDeleteAllFarewellMessage();
    }
  };

  const handleDeleteAllFarewellMessage = async () => {
    try {
      await api.delete(`/farewellMessageAll`);
      toast.success(i18n.t("farewell.toasts.deleted"));
      setTimeout(() => {
        window.location.reload();
      }, 500);
    } catch (err) {
      toastError(err);
    }
    setDeletingFarewellMessage(null);
    setSearchParam("");
    setPageNumber(1);
  };

  const loadMore = () => {
    setPageNumber((prevState) => prevState + 1);
  };

  const handleScroll = (e) => {
    if (!hasMore || loading) return;
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    if (scrollHeight - (scrollTop + 100) < clientHeight) {
      loadMore();
    }
  };

  return (
    <MainContainer>
      <ConfirmationModal
        title={
          deletingFarewellMessage &&
          `${i18n.t("farewell.confirmationModal.deleteTitle")} ${
            deletingFarewellMessage.groupId
          }?`
        }
        open={confirmModalOpen}
        onClose={setConfirmModalOpen}
        onConfirm={() => handleDeleteFarewellMessage(deletingFarewellMessage.id)}
      >
        {i18n.t("farewell.confirmationModal.deleteMessage")}
      </ConfirmationModal>
      <FarewellMessageModal
        open={farewellMessageModalOpen}
        onClose={handleCloseFarewellMessageModal}
        aria-labelledby="form-dialog-title"
        farewellMessageId={selectedFarewellMessage && selectedFarewellMessage.id}
      ></FarewellMessageModal>
      <MainHeader>
        <Title>{i18n.t("farewell.title")}</Title>
        <MainHeaderButtonsWrapper>
          <TextField
            placeholder={i18n.t("farewell.searchPlaceholder")}
            type="search"
            value={searchParam}
            onChange={handleSearch}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon style={{ color: "gray" }} />
                </InputAdornment>
              ),
            }}
          />
          <Button
            variant="contained"
            color="primary"
            onClick={handleOpenFarewellMessageModal}
          >
            {i18n.t("farewell.buttons.add")}
          </Button>
          <Button
            variant="contained"
            color="primary"
            onClick={confirmDeleteAllFarewellMessage}
          >
            {i18n.t("farewell.buttons.delete")}
          </Button>  
        </MainHeaderButtonsWrapper>
      </MainHeader>
      <Paper
        className={classes.mainPaper}
        variant="outlined"
        onScroll={handleScroll}
      >
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell align="center">
                {i18n.t("farewell.table.shortcut")}
              </TableCell>
              <TableCell align="center">
                {i18n.t("farewell.table.message")}
              </TableCell>
              <TableCell align="center">
                {i18n.t("farewell.table.actions")}
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <>
              {farewellMessage.map((message) => (
                <TableRow key={message.id}>
                  <TableCell align="center">{message.groupId === 'all' ? 'Todos os Grupos' : message.groupId}</TableCell>
                  <TableCell align="center">{message.message}</TableCell>
                  <TableCell align="center">
                    <IconButton
                      size="small"
                      onClick={() => handleEditFarewellMessage(message)}
                    >
                      <Edit />
                    </IconButton>

                    <IconButton
                      size="small"
                      onClick={(e) => {
                        setConfirmModalOpen(true);
                        setDeletingFarewellMessage(message);
                      }}
                    >
                      <DeleteOutline />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
              {loading && <TableRowSkeleton columns={3} />}
            </>
          </TableBody>
        </Table>
      </Paper>
    </MainContainer>
  );
};

export default FarewellMessage;
