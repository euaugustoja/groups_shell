import React, { useState, useEffect, useReducer } from "react";
import openSocket from "../../services/socket-io";

import {
  Button,
  IconButton,
  makeStyles,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableRow,
  InputAdornment,
  TextField,
} from "@material-ui/core";
import { DeleteOutline } from "@material-ui/icons";
// import { Edit, DeleteOutline } from "@material-ui/icons";
import SearchIcon from "@material-ui/icons/Search";

import MainContainer from "../../components/MainContainer";
import MainHeader from "../../components/MainHeader";
import MainHeaderButtonsWrapper from "../../components/MainHeaderButtonsWrapper";
import Title from "../../components/Title";

import api from "../../services/api";
import { i18n } from "../../translate/i18n";
import TableRowSkeleton from "../../components/TableRowSkeleton";
import ParticipantsListModal from "../../components/ParticipantsListModal";
import ConfirmationModal from "../../components/ConfirmationModal";
import { toast } from "react-toastify";
import toastError from "../../errors/toastError";

import * as XLSX from "xlsx";

const reducer = (state, action) => {
  if (action.type === "LOAD_PARTICIPANTS_LIST") {
    const participantsList = action.payload;
    const newParticipantsList = [];

    participantsList.forEach((participant) => {
      const participantsIndex = state.findIndex((p) => p.id === participant.id);
      if (participantsIndex !== -1) {
        state[participantsIndex] = participant;
      } else {
        newParticipantsList.push(participant);
      }
    });

    return [...state, ...newParticipantsList];
  }

  if (action.type === "UPDATE_PARTICIPANTS_LIST") {
    const participantsList = action.payload;
    const participantsListIndex = state.findIndex((p) => p.id === participantsList.id);

    if (participantsListIndex !== -1) {
      state[participantsListIndex] = participantsList;
      return [...state];
    } else {
      return [participantsList, ...state];
    }
  }

  if (action.type === "DELETE_PARTICIPANTS_LIST") {
    const participantsListId = action.payload;

    const participantsLisIndex = state.findIndex((p) => p.id === participantsListId);
    if (participantsLisIndex !== -1) {
      state.splice(participantsLisIndex, 1);
    }
    return [...state];
  }

  if (action.type === "RESET") {
    return [];
  }
};


const useStyles = makeStyles((theme) => ({
  mainPaper: {
    flex: 1,
    padding: theme.spacing(1),
    overflowY: "scroll",
    ...theme.scrollbarStyles,
  },
}));

const ParticipantsList = () => {
  const classes = useStyles();

  const [loading, setLoading] = useState(false);
  const [pageNumber, setPageNumber] = useState(1);
  const [searchParam, setSearchParam] = useState("");
  const [participantsList, dispatch] = useReducer(reducer, []);
  const [selectedParticipantsList, setSelectedParticipantsList] = useState(null);
  const [participantsListModalOpen, setParticipantsListModalOpen] = useState(false);
  const [deletingParticipantsList, setDeletingParticipantsList] = useState(null);
  const [confirmModalOpen, setConfirmModalOpen] = useState(false);
  const [hasMore, setHasMore] = useState(false);

  useEffect(() => {
    dispatch({ type: "RESET" });
    setPageNumber(1);
  }, [searchParam]);

  useEffect(() => {
    setLoading(true);
    const delayDebounceFn = setTimeout(() => {
      const fetchParticipantsList = async () => {
        try {
          const { data } = await api.get("/participantsList/", {
            params: { searchParam, pageNumber },
          });
          dispatch({ type: "LOAD_PARTICIPANTS_LIST", payload: data.participantsList });
          setHasMore(data.hasMore);
          setLoading(false);
        } catch (err) {
          toastError(err);
        }
      };
      fetchParticipantsList();
    }, 500);
    return () => clearTimeout(delayDebounceFn);
  }, [searchParam, pageNumber]);

  useEffect(() => {
    const socket = openSocket();

    socket.on("participantsList", (data) => {
      if (data.action === "update" || data.action === "create") {
        dispatch({ type: "UPDATE_PARTICIPANTS_LIST", payload: data.participantsList });
      }

      if (data.action === "delete") {
        dispatch({
          type: "DELETE_PARTICIPANTS_LIST",
          payload: +data.participantsList,
        });
      }
    });

    return () => {
      socket.disconnect();
    };
  }, []);

  const handleSearch = (event) => {
    setSearchParam(event.target.value.toLowerCase());
  };

  // const handleOpenParticipantsListModal = () => {
  //   setSelectedParticipantsList(null);
  //   setParticipantsListModalOpen(true);
  // };

  const handleCloseParticipantsListModal = () => {
    setSelectedParticipantsList(null);
    setParticipantsListModalOpen(false);
  };

  // const handleEditParticipantsList = (participantsList) => {
  //   setSelectedParticipantsList(participantsList);
  //   setParticipantsListModalOpen(true);
  // };

  const handleDeleteParticipantsList = async (participantsListId) => {
    try {
      await api.delete(`/participantsList/${participantsListId}`);
      toast.success(i18n.t("participants.toasts.deleted"));
    } catch (err) {
      toastError(err);
    }
    setDeletingParticipantsList(null);
    setSearchParam("");
    setPageNumber(1);
  };

  const confirmDeleteAllParticipants = () => {
    const confirm = window.confirm(i18n.t("participants.popup.confirm"));
    if (confirm) {
      handleDeleteAllParticipantsList();
    }
  };

  const handleDeleteAllParticipantsList = async () => {
    try {
      await api.delete(`/participantsListAll`);
      toast.success(i18n.t("participants.toasts.deleted"));
      setTimeout(() => {
        window.location.reload();
      }, 500);
    } catch (err) {
      toastError(err);
    }
    setDeletingParticipantsList(null);
    setSearchParam("");
    setPageNumber(1);
  };

  const loadMore = () => {
    setPageNumber((prevState) => prevState + 1);
  };

  const handleScroll = (e) => {
    if (!hasMore || loading) return;
    const { scrollTop, scrollHeight, clientHeight } = e.currentTarget;
    if (scrollHeight - (scrollTop + 100) < clientHeight) {
      loadMore();
    }
  };

  const getAllParticipants = async () => {
    try {
      const { data } = await api.get("/participantsListAll", {
        params: { searchParam },
      });
      return data.participantsList;
    } catch (err) {
      toastError(err);
      return [];
    }
  };

  const exportToExcel = async () => {
    const allParticipants = await getAllParticipants();
  
    const worksheet = XLSX.utils.json_to_sheet(allParticipants);
    const workbook = XLSX.utils.book_new();
  
    XLSX.utils.book_append_sheet(workbook, worksheet, "Participantes");

    XLSX.writeFile(workbook, "participantes.xlsx");
  };

  return (
    <MainContainer>
      <ConfirmationModal
        title={
          deletingParticipantsList &&
          `${i18n.t("participants.confirmationModal.deleteTitle")} ${
            deletingParticipantsList.groupId
          }?`
        }
        open={confirmModalOpen}
        onClose={setConfirmModalOpen}
        onConfirm={() => handleDeleteParticipantsList(deletingParticipantsList.id)}
      >
        {i18n.t("participants.confirmationModal.deleteMessage")}
      </ConfirmationModal>
      <ParticipantsListModal
        open={participantsListModalOpen}
        onClose={handleCloseParticipantsListModal}
        aria-labelledby="form-dialog-title"
        participantsListId={selectedParticipantsList && selectedParticipantsList.id}
      ></ParticipantsListModal>
      <MainHeader>
        <Title>{i18n.t("participants.title")}</Title>
        <MainHeaderButtonsWrapper>
          <TextField
            placeholder={i18n.t("participants.searchPlaceholder")}
            type="search"
            value={searchParam}
            onChange={handleSearch}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon style={{ color: "gray" }} />
                </InputAdornment>
              ),
            }}
          />
          {/* <Button
            variant="contained"
            color="primary"
            onClick={handleOpenParticipantsListModal}
          >
            {i18n.t("participants.buttons.add")}
          </Button> */}
          <Button
            variant="contained"
            color="primary"
            onClick={confirmDeleteAllParticipants}
          >
            {i18n.t("participants.buttons.delete")}
          </Button> 
          <Button
            variant="contained"
            color="secondary"
            onClick={exportToExcel}
          >
            {i18n.t("commonLabels.excelExport")}
          </Button>
        </MainHeaderButtonsWrapper>
      </MainHeader>
      <Paper
        className={classes.mainPaper}
        variant="outlined"
        onScroll={handleScroll}
      >
        <Table size="small">
          <TableHead>
            <TableRow>
              <TableCell align="center">
                {i18n.t("participants.table.shortcut")}
              </TableCell>
              <TableCell align="center">
                {i18n.t("participants.table.name")}
              </TableCell>
              <TableCell align="center">
                {i18n.t("participants.table.user")}
              </TableCell>
              <TableCell align="center">
                {i18n.t("participants.table.actions")}
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            <>
              {participantsList.map((participant) => (
                <TableRow key={participant.id}>
                  <TableCell align="center">{participant.groupId}</TableCell>
                  <TableCell align="center">{participant.name}</TableCell>
                  <TableCell align="center">{participant.user}</TableCell>
                  <TableCell align="center">
                    {/* <IconButton
                      size="small"
                      onClick={() => handleEditParticipantsList(participant)}
                    >
                      <Edit />
                    </IconButton> */}

                    <IconButton
                      size="small"
                      onClick={(e) => {
                        setConfirmModalOpen(true);
                        setDeletingParticipantsList(participant);
                      }}
                    >
                      <DeleteOutline />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
              {loading && <TableRowSkeleton columns={3} />}
            </>
          </TableBody>
        </Table>
      </Paper>
    </MainContainer>
  );
};

export default ParticipantsList;
