import React, { useState, useEffect, useRef } from "react";

import * as Yup from "yup";
import { Formik, Form, Field } from "formik";
import { toast } from "react-toastify";

import {
  makeStyles,
  Button,
  TextField,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  CircularProgress,
} from "@material-ui/core";
import { green } from "@material-ui/core/colors";
import { i18n } from "../../translate/i18n";

import api from "../../services/api";
import toastError from "../../errors/toastError";

import Switch from "@material-ui/core/Switch";

const useStyles = makeStyles((theme) => ({
  root: {
    flexWrap: "wrap",
  },
  textField: {
    marginRight: theme.spacing(1),
    width: "100%",
  },

  btnWrapper: {
    position: "relative",
  },

  buttonProgress: {
    color: green[500],
    position: "absolute",
    top: "50%",
    left: "50%",
    marginTop: -12,
    marginLeft: -12,
  },
  textBanListContainer: {
    width: "100%",
  },
}));

const BanListSchema = Yup.object().shape({
  user: Yup.string()
    .required("Required"),
});

const BanListModal = ({
  open,
  onClose,
  banListId,
  initialValues,
  onSave,
}) => {
  const classes = useStyles();
  const isMounted = useRef(true);

  const initialState = {
    groupId: "",
    user: "",
  };

  const [banList, setBanList] = useState(initialState);
  const [showGroupId, setShowGroupId] = useState(true);

  useEffect(() => {
    return () => {
      isMounted.current = false;
    };
  }, []);

  useEffect(() => {
    const fetchBanList = async () => {
      if (initialValues) {
        setBanList((prevState) => {
          return { ...prevState, ...initialValues };
        });
      }

      if (!banListId) return;

      try {
        const { data } = await api.get(`/banList/${banListId}`);
        if (isMounted.current) {
          setBanList(data);
        }
      } catch (err) {
        toastError(err);
      }
    };

    fetchBanList();
  }, [banListId, open, initialValues]);

  const handleClose = () => {
    onClose();
    setBanList(initialState);
  };

  const handleSaveBanList = async (values) => {
    try {
      if (showGroupId){
        if (banListId) {
          await api.put(`/banList/${banListId}`, values);
          handleClose();
        } else {
          const { data } = await api.post("/banList", values);
          if (onSave) {
            onSave(data);
          }
          handleClose();
        }
      }
      if (!showGroupId){
        const updatedValues = {
          groupId: 'all',
          user: values.user
        }
        if (banListId) {
          await api.put(`/banList/${banListId}`, updatedValues);
          handleClose();
        } else {
          const { data } = await api.post("/banList", updatedValues);
          if (onSave) {
            onSave(data);
          }
          handleClose();
        }
      }
      toast.success(i18n.t("banListModal.success"));
    } catch (err) {
      toastError(err);
    }
  };

  return (
    <div className={classes.root}>
      <Dialog
        open={open}
        onClose={handleClose}
        maxWidth="sm"
        fullWidth
        scroll="paper"
      >
        <DialogTitle id="form-dialog-title">
          {banListId
            ? `${i18n.t("banListModal.title.edit")}`
            : `${i18n.t("banListModal.title.add")}`}
        </DialogTitle>
        <Formik
          initialValues={banList}
          enableReinitialize={true}
          validationSchema={BanListSchema}
          onSubmit={(values, actions) => {
            setTimeout(() => {
              handleSaveBanList(values);
              actions.setSubmitting(false);
            }, 400);
          }}
        >
          {({ values, errors, touched, isSubmitting }) => (
            <Form>
              <DialogContent dividers>
                <div className={classes.textBanListContainer}>
                  {showGroupId && (
                    <Field
                      as={TextField}
                      label={i18n.t("banListModal.form.groupId")}
                      name="groupId"
                      autoFocus
                      error={touched.groupId && Boolean(errors.groupId)}
                      helperText={touched.groupId && errors.groupId}
                      variant="outlined"
                      margin="dense"
                      className={classes.textField}
                      fullWidth
                    />
                  )}
                </div>
                <div className={classes.textBanListContainer}>
                  <Field
                    as={TextField}
                    label={i18n.t("banListModal.form.ban")}
                    name="user"
                    error={touched.user && Boolean(errors.user)}
                    helperText={touched.user && errors.user}
                    variant="outlined"
                    margin="dense"
                    className={classes.textField}
                    multiline
                    minRows={5}
                    fullWidth
                  />
                </div>
                <div>
                  <Switch
                    checked={!showGroupId}
                    onChange={() => setShowGroupId(!showGroupId)}
                  />
                  <span>{i18n.t("banListModal.buttons.toggle")}</span>
                </div>
              </DialogContent>
              <DialogActions>
                <Button
                  onClick={handleClose}
                  color="secondary"
                  disabled={isSubmitting}
                  variant="outlined"
                >
                  {i18n.t("banListModal.buttons.cancel")}
                </Button>
                <Button
                  type="submit"
                  color="primary"
                  disabled={isSubmitting}
                  variant="contained"
                  className={classes.btnWrapper}
                >
                  {banListId
                    ? `${i18n.t("banListModal.buttons.okEdit")}`
                    : `${i18n.t("banListModal.buttons.okAdd")}`}
                  {isSubmitting && (
                    <CircularProgress
                      size={24}
                      className={classes.buttonProgress}
                    />
                  )}
                </Button>
              </DialogActions>
            </Form>
          )}
        </Formik>
      </Dialog>
    </div>
  );
};

export default BanListModal;
